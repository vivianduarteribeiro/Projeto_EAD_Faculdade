from pymongo import MongoClient
import os

def get_mongo_client():
    uri = os.getenv("MONGO_URI", "mongodb://root:example@mongo:27017/")
    return MongoClient(uri)

def get_collection():
    db_name = os.getenv("MONGO_DB", "eshop")
    coll_name = os.getenv("MONGO_COLLECTION", "orders")
    client = get_mongo_client()
    return client[db_name][coll_name]
